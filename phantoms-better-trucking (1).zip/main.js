// Firebase config and app logic are included here, already shared above
// (Use your updated Main.js from the canvas)